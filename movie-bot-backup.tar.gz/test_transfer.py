import asyncio
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

import pytest
from telegram.error import BadRequest, Forbidden, NetworkError, RetryAfter, TimedOut

import transfer
from downloader import MIB, Config, DownloadError, Probe
from jobs import Job, JobManager, UploadFatal, UploadRetry

PR = Probe("https://files.example.com/a.mp4", 5 * MIB, "video/mp4", "abc.mp4")


@pytest.fixture(autouse=True)
def fresh(tmp_path, monkeypatch):
    monkeypatch.setattr(transfer, "CFG", Config(work_dir=tmp_path / "w", disk_reserve_bytes=0))
    monkeypatch.setattr(transfer, "MANAGER", JobManager(transfer.CFG))
    monkeypatch.setattr(transfer, "ALLOWED", frozenset({1}))


def msg_update(user=1, chat=10):
    m = SimpleNamespace(reply_text=AsyncMock())
    return SimpleNamespace(message=m, effective_user=SimpleNamespace(id=user), effective_chat=SimpleNamespace(id=chat))


def ctx(*args):
    return SimpleNamespace(args=list(args), bot=SimpleNamespace(send_document=AsyncMock()))


def last(upd):
    return upd.message.reply_text.await_args.args[0]


def go(c):
    return asyncio.run(c)


def test_disabled_without_allowlist(monkeypatch):
    monkeypatch.setattr(transfer, "ALLOWED", frozenset())
    u = msg_update()
    go(transfer.download_command(u, ctx("https://a.example.com/x.mp4")))
    assert "disabled" in last(u)


def test_unauthorized_user():
    u = msg_update(user=2)
    go(transfer.download_command(u, ctx("https://a.example.com/x.mp4")))
    assert "not authorized" in last(u)


def test_usage_on_bad_url():
    for args in ([], ["javascript:x"], ["https://127.0.0.1/a.mp4"]):
        u = msg_update()
        go(transfer.download_command(u, ctx(*args)))
        assert "Usage" in last(u)


def test_oversize_rejected_clearly():
    u = msg_update()
    big = Probe(PR.url, 200 * MIB, "video/mp4", "b.mp4")
    with patch.object(transfer, "probe", AsyncMock(return_value=big)):
        go(transfer.download_command(u, ctx("https://files.example.com/a.mp4")))
    assert "50 MB" in last(u) and "can't download this link" in last(u)
    assert not transfer.MANAGER.pending


def test_probe_error_reported():
    u = msg_update()
    with patch.object(transfer, "probe", AsyncMock(side_effect=DownloadError("That link is a web page"))):
        go(transfer.download_command(u, ctx("https://files.example.com/a")))
    assert "web page" in last(u)


def test_confirmation_prompt_then_job_runs():
    async def main():
        u = msg_update()
        with patch.object(transfer, "probe", AsyncMock(return_value=PR)):
            await transfer.download_command(u, ctx("https://files.example.com/a.mp4"))
        kb = u.message.reply_text.await_args.kwargs["reply_markup"]
        data = kb.inline_keyboard[0][0].callback_data
        assert data.startswith("dl:ok:") and len(data.encode()) <= 64
        q = SimpleNamespace(data=data, answer=AsyncMock(), edit_message_text=AsyncMock(),
                            message=SimpleNamespace(edit_text=AsyncMock()))
        cu = SimpleNamespace(callback_query=q, effective_user=SimpleNamespace(id=1), effective_chat=SimpleNamespace(id=10))
        ran = []

        async def fake_run(job, notify, upload, client=None):
            ran.append(job.user_id)
        with patch.object(transfer.MANAGER, "run", fake_run):
            await transfer.on_transfer_button(cu, ctx())
            await asyncio.sleep(0.05)
            assert ran == [1]
            # a second press of the same button is rejected (single use)
            await transfer.on_transfer_button(cu, ctx())
            assert "expired" in q.edit_message_text.await_args.args[0]
    go(main())


def test_confirmation_bound_to_user_and_chat():
    pid = transfer.MANAGER.add_pending(1, 10, PR)
    for user, chat in ((2, 10), (1, 11)):
        q = SimpleNamespace(data=f"dl:ok:{pid}", answer=AsyncMock(), edit_message_text=AsyncMock(), message=None)
        transfer.ALLOWED = frozenset({1, 2})
        cu = SimpleNamespace(callback_query=q, effective_user=SimpleNamespace(id=user), effective_chat=SimpleNamespace(id=chat))
        go(transfer.on_transfer_button(cu, ctx()))
        assert "expired" in q.edit_message_text.await_args.args[0]


def test_cancel_command():
    u = msg_update()
    go(transfer.cancel_command(u, ctx()))
    assert "no active transfer" in last(u)

    async def main():
        job = transfer.MANAGER.create(1, 10, PR)
        job.state = "downloading"
        job.task = asyncio.create_task(asyncio.sleep(10))
        u2 = msg_update()
        await transfer.cancel_command(u2, ctx())
        assert "Cancelling" in last(u2)
        with pytest.raises(asyncio.CancelledError):
            await job.task
    go(main())


def _job(tmp_path):
    f = tmp_path / "f.mp4"
    f.write_bytes(b"x")
    return Job("j", 1, 10, PR, tmp_path, file=f)


@pytest.mark.parametrize("exc,expected", [
    (RetryAfter(3), UploadRetry), (TimedOut("t"), UploadRetry), (NetworkError("n"), UploadRetry),
    (BadRequest("too big"), UploadFatal), (Forbidden("blocked"), UploadFatal)])
def test_upload_error_mapping(tmp_path, exc, expected):
    bot = SimpleNamespace(send_document=AsyncMock(side_effect=exc))
    with pytest.raises(expected):
        go(transfer.make_uploader(bot)(_job(tmp_path)))


def test_upload_success_sends_document(tmp_path):
    bot = SimpleNamespace(send_document=AsyncMock())
    go(transfer.make_uploader(bot)(_job(tmp_path)))
    assert bot.send_document.await_args.args[0] == 10
    assert bot.send_document.await_args.kwargs["filename"] == "abc.mp4"


def test_notify_tolerates_edit_errors_and_shows_buttons(tmp_path):
    m = SimpleNamespace(edit_text=AsyncMock(side_effect=[BadRequest("not modified"), RetryAfter(1), None, None, None]))
    notify = transfer.make_notify(m)
    job = _job(tmp_path)
    job.state = "downloading"
    go(notify(job, "a")); go(notify(job, "b")); go(notify(job, "c"))
    assert m.edit_text.await_args.kwargs["reply_markup"].inline_keyboard[0][0].callback_data == "dl:cancel:j"
    job.state = "upload_failed"
    go(notify(job, "d"))
    assert m.edit_text.await_args.kwargs["reply_markup"].inline_keyboard[0][0].callback_data == "dl:retry:j"
    job.state = "done"
    go(notify(job, "e"))
    assert m.edit_text.await_args.kwargs["reply_markup"] is None
