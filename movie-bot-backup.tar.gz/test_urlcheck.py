from urlcheck import validate_topcinema_url as v

GOOD = ["https://web.topcinema.io/film/1", "http://WEB.TOPCINEMA.IO/", "https://cdn.web.topcinema.io/x", "https://web.topcinema.io:443/a"]
BAD = ["https://evil.com/", "https://web.topcinema.io.evil.com/", "https://evilweb.topcinema.io/",
       "https://topcinema.io/", "https://web.topcinema.io@evil.com/", "https://evil.com/web.topcinema.io",
       "ftp://web.topcinema.io/", "javascript:alert(1)", "https://web.topcinema.io:8080/", "", "https://web.topcinema.io/ a"]

def test_good():
    for u in GOOD: assert v(u), u

def test_bad():
    for u in BAD: assert not v(u), u
