"""Syntax-only validation of third-party download landing-page URLs.

A passing result means the URL is well-formed and not obviously unsafe in shape.
It is NOT proof that the link is safe, trustworthy, or working. The bot never
requests these URLs.
"""
import ipaddress
import re
from typing import Optional
from urllib.parse import urlsplit

_LABEL_RE = re.compile(r"^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$")
_BLOCKED_SUFFIXES = (".local", ".localhost", ".internal", ".lan", ".home", ".corp", ".intranet")
MAX_LEN = 2048


def validate_external_url(url: str) -> Optional[str]:
    """Return a cleaned http(s) URL, or None if it fails the syntax checks."""
    if not isinstance(url, str) or not url or len(url) > MAX_LEN:
        return None
    url = url.strip()
    if any(c.isspace() or ord(c) < 32 or ord(c) == 127 for c in url):
        return None
    try:
        parts = urlsplit(url)
        host = parts.hostname
        port = parts.port
    except ValueError:
        return None
    if parts.scheme not in ("http", "https") or not host:
        return None
    if parts.username is not None or parts.password is not None:
        return None
    if port not in (None, 80, 443):
        return None
    host = host.rstrip(".")
    if not host.isascii():
        return None
    try:
        ipaddress.ip_address(host)
        return None  # IP literals are rejected
    except ValueError:
        pass
    labels = host.split(".")
    if len(labels) < 2 or len(host) > 253:
        return None
    if host == "localhost" or host.endswith(_BLOCKED_SUFFIXES):
        return None
    if not all(_LABEL_RE.match(l) for l in labels) or any(l.startswith("xn--") for l in labels):
        return None
    if labels[-1].isdigit():
        return None
    return url
