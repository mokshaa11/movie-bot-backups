"""Fetch a TopCinema page and list publicly exposed video sources.

Scope: only URLs that appear in the page's own HTML (<video>/<source> tags and
plain media links in the markup). Nothing is downloaded or uploaded. DRM-protected
streams, logins and paywalls are never bypassed: such pages are reported as unsupported.
"""
import asyncio
import ipaddress
import logging
import re
import socket
from dataclasses import dataclass, field
from html import unescape
from typing import List, Optional
from urllib.parse import urljoin, urlsplit

import httpx

from urlcheck import validate_topcinema_url

log = logging.getLogger("movie-bot.extractor")

MAX_BYTES = 2 * 1024 * 1024
MAX_REDIRECTS = 3
TIMEOUT = httpx.Timeout(10.0)
USER_AGENT = "Mozilla/5.0 (compatible; MovieBot/0.2; metadata-only)"

MEDIA_EXT = (".mp4", ".webm", ".m3u8")
_MEDIA_URL_RE = re.compile(r"""https?:(?:\\?/){2}(?:[^\s"'<>\\]|\\/)+?\.(?:mp4|webm|m3u8)(?:\?[^\s"'<>\\]*)?""", re.I)
_TAG_RE = re.compile(r"<(video|source)\b([^>]*)>", re.I)
_ATTR_RE = re.compile(r"""([a-zA-Z_:-]+)\s*=\s*(?:"([^"]*)"|'([^']*)')""")
_QUALITY_RE = re.compile(r"(?<!\d)(2160|1440|1080|720|576|480|360|240)\s*p?(?!\d)", re.I)
_DRM_RE = re.compile(r"widevine|playready|fairplay|com\.microsoft\.playready|requestMediaKeySystemAccess|#EXT-X-KEY:METHOD=(?!NONE)", re.I)


class ExtractionError(Exception):
    """Raised with a user-safe message when a page cannot be processed."""


@dataclass
class VideoSource:
    url: str
    kind: str  # "mp4", "webm" or "hls"
    quality: Optional[str] = None


@dataclass
class DownloadLink:
    host: str  # label shown on the site, e.g. "UpDown"
    quality: str  # e.g. "1080p" or "1080p - 720p - 480p"
    url: str


@dataclass
class ExtractionResult:
    title: Optional[str] = None
    sources: List[VideoSource] = field(default_factory=list)
    embeds: List[str] = field(default_factory=list)  # third-party players; listed, not fetched
    drm_detected: bool = False
    downloads: List["DownloadLink"] = field(default_factory=list)  # third-party host pages; listed, not fetched


def _is_public_ip(ip: str) -> bool:
    return ipaddress.ip_address(ip).is_global


async def _check_host_public(host: str) -> None:
    """Reject hosts resolving to private/loopback addresses (SSRF guard)."""
    loop = asyncio.get_running_loop()
    try:
        infos = await loop.getaddrinfo(host, None, type=socket.SOCK_STREAM)
    except socket.gaierror:
        raise ExtractionError("Could not resolve the site address.")
    if not infos or not all(_is_public_ip(i[4][0]) for i in infos):
        raise ExtractionError("The address is not a public host.")


def new_client() -> httpx.AsyncClient:
    """HTTP client with a cookie jar (ordinary browser-like session), no auto-redirects."""
    return httpx.AsyncClient(timeout=TIMEOUT, follow_redirects=False, headers={"User-Agent": USER_AGENT})


async def fetch_page(url: str, client: Optional[httpx.AsyncClient] = None, *, method: str = "GET",
                     data: Optional[dict] = None, headers: Optional[dict] = None,
                     check_dns: Optional[bool] = None) -> str:
    """Fetch HTML, following a few redirects only within the allowed domain."""
    own = client is None
    client = client or new_client()
    check_dns = own if check_dns is None else check_dns
    try:
        current = url
        for _ in range(MAX_REDIRECTS + 1):
            if not validate_topcinema_url(current):
                raise ExtractionError("The page redirected outside the allowed domain.")
            if check_dns:
                await _check_host_public(urlsplit(current).hostname)
            async with client.stream(method, current, data=data, headers=headers) as resp:
                if resp.is_redirect:
                    loc = resp.headers.get("location")
                    if not loc:
                        raise ExtractionError("Bad redirect from the site.")
                    current = urljoin(current, loc)
                    continue
                if resp.status_code in (401, 402, 403):
                    raise ExtractionError("The page requires access I don't have (login or restricted). I can't process it.")
                if resp.status_code != 200:
                    raise ExtractionError(f"The site returned HTTP {resp.status_code}.")
                if "html" not in resp.headers.get("content-type", "").lower():
                    raise ExtractionError("The URL did not return an HTML page.")
                data = bytearray()
                async for chunk in resp.aiter_bytes():
                    data += chunk
                    if len(data) > MAX_BYTES:
                        raise ExtractionError("The page is too large to process.")
                return data.decode(resp.encoding or "utf-8", errors="replace")
        raise ExtractionError("Too many redirects.")
    except httpx.TimeoutException:
        raise ExtractionError("The site took too long to respond.")
    except httpx.HTTPError as exc:
        log.warning("HTTP error while fetching page: %s", type(exc).__name__)
        raise ExtractionError("Could not reach the site.")
    finally:
        if own:
            await client.aclose()


def _kind(url: str) -> Optional[str]:
    path = urlsplit(url).path.lower()
    if path.endswith(".m3u8"):
        return "hls"
    if path.endswith(".mp4"):
        return "mp4"
    if path.endswith(".webm"):
        return "webm"
    return None


def _quality(*texts: Optional[str]) -> Optional[str]:
    for t in texts:
        if t and (m := _QUALITY_RE.search(t)):
            return m.group(1) + "p"
    return None


def _clean(raw: str, base: str) -> Optional[str]:
    url = urljoin(base, unescape(raw.replace("\\/", "/")).strip())
    parts = urlsplit(url)
    if parts.scheme not in ("http", "https") or not parts.hostname or parts.username:
        return None
    return url


def parse_page(html: str, base_url: str) -> ExtractionResult:
    """Extract public video sources and quality labels from page HTML."""
    result = ExtractionResult()
    if m := re.search(r"<title[^>]*>(.*?)</title>", html, re.I | re.S):
        result.title = unescape(re.sub(r"\s+", " ", m.group(1))).strip()[:200] or None
    result.drm_detected = bool(_DRM_RE.search(html))
    seen = set()

    def add(url: Optional[str], quality: Optional[str]) -> None:
        if not url or url in seen or not (kind := _kind(url)):
            return
        seen.add(url)
        result.sources.append(VideoSource(url, kind, quality or _quality(urlsplit(url).path)))

    for tag in _TAG_RE.finditer(html):
        attrs = {k.lower(): (a or b) for k, a, b in _ATTR_RE.findall(tag.group(2))}
        if src := attrs.get("src"):
            add(_clean(src, base_url), _quality(attrs.get("label"), attrs.get("res"),
                                                attrs.get("title"), attrs.get("data-quality"),
                                                attrs.get("size")))
    for m in _MEDIA_URL_RE.finditer(html):
        add(_clean(m.group(0), base_url), None)

    for m in re.finditer(r"<iframe\b[^>]*\bsrc\s*=\s*[\"']([^\"']+)", html, re.I):
        url = _clean(m.group(1), base_url)
        if url and url not in result.embeds:
            result.embeds.append(url)

    if result.drm_detected:
        # Never offer streams from a page that signals DRM.
        result.sources = []
    result.sources.sort(key=lambda s: -int((s.quality or "0p")[:-1]))
    return result


_DL_LINK_RE = re.compile(
    r"<a\b[^>]*\bhref=\"(https?://[^\"]+)\"[^>]*class=\"[^\"]*downloadsLink[^\"]*\"[^>]*>(.*?)</a>", re.I | re.S)
_DL_BLOCK_RE = re.compile(r"<h2 class=\"download-title\"><i[^>]*></i>[^<]*<span>([^<]+)</span>", re.I)
_SPAN_P_RE = re.compile(r"<span>([^<]*)</span>\s*<p>([^<]*)</p>", re.I)
_SERVER_RE = re.compile(r"<li[^>]*data-id=\"(\d+)\"[^>]*data-server=\"(\d+)\"", re.I)
_IFRAME_RE = re.compile(r"<iframe\b[^>]*\bsrc=\"(https?://[^\"]+)\"", re.I)
SERVER_ENDPOINT = "https://web.topcinema.io/wp-content/themes/movies2023/Ajaxat/Single/Server.php"
MAX_SERVERS = 10


def base_page_url(url: str) -> str:
    """Strip /watch/, /download/ suffixes and the query string from a post URL."""
    parts = urlsplit(url)
    path = re.sub(r"/(watch|download)/?$", "/", parts.path)
    if not path.endswith("/"):
        path += "/"
    return f"{parts.scheme}://{parts.netloc}{path}"


def parse_download_page(html: str) -> List[DownloadLink]:
    """Read the public download-server list: host label, quality and link (never opened)."""
    blocks = [(m.start(), m.group(1).strip()) for m in _DL_BLOCK_RE.finditer(html)]
    links: List[DownloadLink] = []
    seen = set()
    for m in _DL_LINK_RE.finditer(html):
        url = unescape(m.group(1)).strip()
        if url in seen or urlsplit(url).username:
            continue
        seen.add(url)
        label = _SPAN_P_RE.search(m.group(2))
        host = unescape(label.group(1)).strip() if label else urlsplit(url).hostname or "?"
        quality = unescape(label.group(2)).strip() if label else ""
        if not quality:  # fall back to the enclosing "Download <quality>" block heading
            before = [q for pos, q in blocks if pos < m.start()]
            quality = before[-1] if before else "unknown"
        links.append(DownloadLink(host[:40], quality[:60], url))
    return links


def parse_server_list(html: str) -> List[tuple]:
    """Return (post_id, server_index) pairs from the watch page server tabs."""
    pairs = []
    for pid, idx in _SERVER_RE.findall(html):
        if (pid, idx) not in pairs:
            pairs.append((pid, idx))
    return pairs[:MAX_SERVERS]


def parse_embed_snippet(html: str) -> Optional[str]:
    """Return the iframe URL from a server snippet (listed only, never fetched)."""
    m = _IFRAME_RE.search(html)
    return unescape(m.group(1)) if m else None


async def extract_sources(url: str, client: Optional[httpx.AsyncClient] = None) -> ExtractionResult:
    """Inspect the post, /download/ and /watch/ pages plus the site's own server endpoint.

    Only web.topcinema.io is contacted. Third-party player and file-host URLs are
    collected as text and never requested.
    """
    own = client is None
    client = client or new_client()
    try:
        main = await fetch_page(url, client, check_dns=own)
        result = parse_page(main, url)
        base = base_page_url(url)
        extras = {}
        for name in ("download", "watch"):
            try:
                extras[name] = await fetch_page(f"{base}{name}/", client, check_dns=own)
            except ExtractionError as exc:
                log.info("Optional %s page unavailable: %s", name, exc)
        if "download" in extras:
            result.downloads = parse_download_page(extras["download"])
        if "watch" in extras:
            watch_html = extras["watch"]
            for src in parse_page(watch_html, base).sources:
                if src.url not in {s.url for s in result.sources}:
                    result.sources.append(src)
            for e in parse_page(watch_html, base).embeds:
                if e not in result.embeds:
                    result.embeds.append(e)
            for pid, idx in parse_server_list(watch_html):
                try:
                    snippet = await fetch_page(SERVER_ENDPOINT, client, method="POST",
                                               data={"id": pid, "i": idx}, check_dns=own,
                                               headers={"Referer": f"{base}watch/",
                                                        "X-Requested-With": "XMLHttpRequest"})
                except ExtractionError:
                    continue
                if (embed := parse_embed_snippet(snippet)) and embed not in result.embeds:
                    result.embeds.append(embed)
        return result
    finally:
        if own:
            await client.aclose()
