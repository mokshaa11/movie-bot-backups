"""Safe streaming download of authorized, DIRECT file URLs only.

Never follows landing pages, solves captchas/timers, or uses cookies/credentials.
HTML responses are refused. Every redirect hop is re-validated and DNS-checked.
"""
import asyncio
import ipaddress
import logging
import os
import re
import secrets
import shutil
import socket
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Awaitable, Callable, Optional
from urllib.parse import unquote, urljoin, urlsplit

import httpx

from linkcheck import validate_external_url

log = logging.getLogger("movie-bot.downloader")

MIB = 1024 * 1024
# Standard (cloud) Bot API upload limit is 50 MB; stay slightly under to be safe.
STANDARD_API_UPLOAD_LIMIT = 50 * 1000 * 1000
ALLOWED_EXTENSIONS = (".mp4", ".mkv", ".webm", ".mov", ".m4v", ".avi")
MAX_REDIRECTS = 3
CHUNK = 1 * MIB
USER_AGENT = "MovieBot/0.3 (direct-download)"


class DownloadError(Exception):
    """Raised with a user-safe message."""


class Cancelled(Exception):
    pass


@dataclass
class Config:
    max_download_bytes: int = 1024 * MIB  # MAX_DOWNLOAD_MB, default 1 GiB
    upload_limit_bytes: int = STANDARD_API_UPLOAD_LIMIT
    disk_reserve_bytes: int = 2 * 1024 * MIB
    work_dir: Path = Path("/var/tmp/movie-bot")
    total_timeout: float = 900.0
    idle_timeout: float = 30.0

    @property
    def effective_limit(self) -> int:
        """Largest file we will download: it must also be uploadable."""
        return min(self.max_download_bytes, self.upload_limit_bytes)

    @classmethod
    def from_env(cls) -> "Config":
        cfg = cls()
        raw = os.environ.get("MAX_DOWNLOAD_MB", "").strip()
        if raw:
            try:
                mb = int(raw)
                if mb > 0:
                    cfg.max_download_bytes = mb * MIB
            except ValueError:
                log.warning("Ignoring invalid MAX_DOWNLOAD_MB")
        if os.environ.get("DOWNLOAD_DIR"):
            cfg.work_dir = Path(os.environ["DOWNLOAD_DIR"])
        return cfg


@dataclass
class Probe:
    url: str  # final URL after validated redirects
    size: Optional[int]
    content_type: str
    filename: str  # safe, random name with allowlisted extension


def parse_allowed_users(raw: str) -> frozenset:
    """Parse ALLOWED_USER_IDS ('123,456') into a set of ints; invalid items are ignored."""
    ids = set()
    for part in (raw or "").split(","):
        part = part.strip()
        if part.isdigit():
            ids.add(int(part))
    return frozenset(ids)


def _is_public_ip(ip: str) -> bool:
    return ipaddress.ip_address(ip).is_global


async def check_host_public(host: str) -> None:
    loop = asyncio.get_running_loop()
    try:
        infos = await loop.getaddrinfo(host, None, type=socket.SOCK_STREAM)
    except socket.gaierror:
        raise DownloadError("Could not resolve the host name.")
    if not infos or not all(_is_public_ip(i[4][0]) for i in infos):
        raise DownloadError("That address is not a public host.")


def _ext_from(url: str, content_disposition: str) -> Optional[str]:
    candidates = []
    if m := re.search(r"filename\*?=(?:UTF-8'')?\"?([^\";]+)", content_disposition or "", re.I):
        candidates.append(unquote(m.group(1)).lower())
    candidates.append(unquote(urlsplit(url).path).lower())
    for c in candidates:
        for ext in ALLOWED_EXTENSIONS:
            if c.endswith(ext):
                return ext
    return None


def new_client(timeout: float = 30.0) -> httpx.AsyncClient:
    """No cookies are kept across jobs; redirects handled manually."""
    return httpx.AsyncClient(timeout=httpx.Timeout(timeout, connect=10.0), follow_redirects=False,
                             headers={"User-Agent": USER_AGENT})


async def _open(client: httpx.AsyncClient, url: str, method: str, headers: Optional[dict],
                check_dns: bool):
    """Return (response_cm, final_url) following validated redirects; caller must close."""
    current = url
    for _ in range(MAX_REDIRECTS + 1):
        if not validate_external_url(current):
            raise DownloadError("The link (or a redirect) failed validation.")
        if check_dns:
            await check_host_public(urlsplit(current).hostname)
        req = client.build_request(method, current, headers=headers)
        resp = await client.send(req, stream=True)
        if resp.is_redirect:
            loc = resp.headers.get("location")
            await resp.aclose()
            if not loc:
                raise DownloadError("Bad redirect.")
            current = urljoin(current, loc)
            continue
        return resp, current
    raise DownloadError("Too many redirects.")


def _check_response(resp: httpx.Response, final_url: str) -> Probe:
    if resp.status_code in (401, 402, 403, 407):
        raise DownloadError("The server requires access I don't have (login or restricted). I can't download it.")
    if resp.status_code not in (200, 206):
        raise DownloadError(f"The server returned HTTP {resp.status_code}.")
    ctype = resp.headers.get("content-type", "").split(";")[0].strip().lower()
    if "html" in ctype or ctype in ("text/plain", "application/json", "application/xml"):
        raise DownloadError("That link is a web page, not a direct file link. I only accept direct file URLs.")
    ext = _ext_from(final_url, resp.headers.get("content-disposition", ""))
    if not (ctype.startswith("video/") or ctype == "application/octet-stream" or ext):
        raise DownloadError("The link does not look like a video file.")
    if not ext:
        ext = {"video/mp4": ".mp4", "video/webm": ".webm", "video/x-matroska": ".mkv",
               "video/quicktime": ".mov"}.get(ctype)
    if not ext:
        raise DownloadError("Unsupported or unknown video file type.")
    size = None
    cr = resp.headers.get("content-range", "")
    if m := re.search(r"/(\d+)$", cr):
        size = int(m.group(1))
    elif resp.status_code == 200 and (cl := resp.headers.get("content-length", "")).isdigit():
        size = int(cl)
    return Probe(final_url, size, ctype, secrets.token_hex(8) + ext)


async def probe(url: str, client: Optional[httpx.AsyncClient] = None) -> Probe:
    """Inspect a direct URL without downloading the body (HEAD, then a 1-byte ranged GET)."""
    own = client is None
    client = client or new_client()
    try:
        try:
            resp, final = await _open(client, url, "HEAD", None, own)
            ok = resp.status_code in (200, 206)
            try:
                if ok:
                    return _check_response(resp, final)
            finally:
                await resp.aclose()
        except httpx.HTTPError:
            pass
        resp, final = await _open(client, url, "GET", {"Range": "bytes=0-0"}, own)
        try:
            return _check_response(resp, final)
        finally:
            await resp.aclose()
    except httpx.TimeoutException:
        raise DownloadError("The server took too long to respond.")
    except httpx.HTTPError:
        raise DownloadError("Could not reach the server.")
    finally:
        if own:
            await client.aclose()


def check_size_allowed(size: Optional[int], cfg: Config) -> None:
    """Reject early, with a clear message, if the file cannot be downloaded and uploaded."""
    if size is None:
        return
    if size > cfg.upload_limit_bytes:
        raise DownloadError(
            f"This file is {size / MIB:.0f} MiB, above the standard Telegram Bot API upload limit of "
            f"{cfg.upload_limit_bytes // 1_000_000} MB. Uploading larger files is not supported yet, so I won't download it.")
    if size > cfg.max_download_bytes:
        raise DownloadError(f"This file is larger than the {cfg.max_download_bytes // MIB} MiB download limit.")
    check_disk(cfg, size)


def check_disk(cfg: Config, needed: int = 0) -> None:
    cfg.work_dir.mkdir(parents=True, exist_ok=True)
    free = shutil.disk_usage(cfg.work_dir).free
    if free - needed < cfg.disk_reserve_bytes:
        raise DownloadError("Not enough free disk space on the server for this file.")


ProgressCb = Callable[[int, Optional[int]], Awaitable[None]]


async def download(pr: Probe, dest_dir: Path, cfg: Config, progress: Optional[ProgressCb] = None,
                   client: Optional[httpx.AsyncClient] = None) -> Path:
    """Stream the file to dest_dir. Returns the final path. Cleans its .part file on failure."""
    own = client is None
    client = client or new_client(cfg.idle_timeout)
    dest_dir.mkdir(parents=True, exist_ok=True)
    final = dest_dir / pr.filename
    part = final.with_suffix(final.suffix + ".part")
    limit = cfg.effective_limit
    try:
        async with asyncio.timeout(cfg.total_timeout):
            resp, _ = await _open(client, pr.url, "GET", None, own)
            try:
                _check_response(resp, pr.url)
                total = pr.size
                if (cl := resp.headers.get("content-length", "")).isdigit():
                    total = int(cl)
                check_size_allowed(total, cfg)
                done = 0
                last_disk = 0
                with open(part, "wb") as fh:
                    async for chunk in resp.aiter_bytes(CHUNK):
                        done += len(chunk)
                        if done > limit:
                            raise DownloadError("The file exceeds the allowed size limit; download stopped.")
                        if done - last_disk >= 64 * MIB:
                            last_disk = done
                            check_disk(cfg)
                        fh.write(chunk)
                        if progress:
                            await progress(done, total)
                if total is not None and done != total:
                    raise DownloadError("The download was incomplete. Please try again.")
            finally:
                await resp.aclose()
        os.replace(part, final)
        return final
    except TimeoutError:
        raise DownloadError("The download took too long and was stopped.")
    except httpx.TimeoutException:
        raise DownloadError("The server stopped responding.")
    except httpx.HTTPError:
        raise DownloadError("The connection failed during download.")
    except OSError:
        raise DownloadError("Could not write the file on the server.")
    finally:
        part.unlink(missing_ok=True)  # only a successful os.replace leaves the final file
        if own:
            await client.aclose()


def sweep_stale(work_dir: Path, max_age: float = 3600.0) -> int:
    """Delete job folders older than max_age seconds. Returns how many were removed."""
    removed = 0
    if not work_dir.is_dir():
        return 0
    now = time.time()
    for p in work_dir.iterdir():
        try:
            if p.is_dir() and now - p.stat().st_mtime > max_age:
                shutil.rmtree(p, ignore_errors=True)
                removed += 1
        except OSError:
            continue
    return removed
