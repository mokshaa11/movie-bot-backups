# TopCinema Telegram Bot

A Telegram bot built with `python-telegram-bot`. It accepts TopCinema links and validates them.
**Video downloading/uploading is not implemented yet.** The bot does not bypass DRM, paywalls, or access controls.

## Setup
```
python -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt
export BOT_TOKEN="<your token from @BotFather>"
python bot.py
```

## Behavior
- `/start`, `/help` – info messages.
- Only `web.topcinema.io` and its subdomains (http/https) are accepted; others are rejected.
- The token is read from `BOT_TOKEN` only and is redacted from logs.

## Tests
```
pip install pytest && pytest
```

## Source extraction (metadata only)
When given a valid link, the bot fetches the page (HTTPS/HTTP, max 2 MB, 10 s timeout, redirects only within
`web.topcinema.io`, private IPs blocked) and lists video URLs found in the page HTML (`<video>`/`<source>` tags and
plain `.mp4`/`.webm`/`.m3u8` links) with quality labels when available. Pages that signal DRM are reported as
unsupported. Nothing is downloaded or uploaded.

### How TopCinema exposes sources (investigated)
- The post page has no video tags. `<post>/download/` publicly lists download hosts with quality labels; `<post>/watch/`
  lists server tabs, and the site's own endpoint (`.../Ajaxat/Single/Server.php`, an ordinary browser-style request)
  returns one third-party `<iframe>` per server.
- The bot reports those download and player links as text only. It never requests third-party hosts. Direct video
  files and quality playlists live behind those third-party players and are not extracted.

## Quality menu
After extraction, the bot shows inline buttons grouped by quality (highest first). Choosing one lists the download
landing pages for that quality as URL buttons (known premium hosts are labeled "Premium"). Links get syntax-only
validation (`linkcheck.py`): this is not proof that a link is safe or working. The bot never opens third-party URLs,
embedded players are not shown, and downloading/uploading is not implemented. Menus are kept in memory for 30 minutes.

## Direct downloads (`/download`)
`/download <direct file URL>` downloads a **direct video file** (mp4, mkv, webm, mov, m4v, avi) and sends it to the chat.
- **Access:** only users listed in `ALLOWED_USER_IDS` (comma-separated numeric IDs). If unset, downloads are disabled.
  The user must press a confirmation button stating they have the right to download the file.
- **Not supported:** web pages, landing pages, logins, captchas/timers, DRM or any access-control bypass. The bot never
  downloads from TopCinema pages or the third-party links in the quality menu.
- **Limits:** `MAX_DOWNLOAD_MB` (default 1024), a 2 GB free-disk reserve, and the standard Bot API upload limit of 50 MB.
  Larger files are rejected before downloading (a local Bot API server is not set up yet). One active transfer per user.
- **Progress / cancel:** one status message is edited every few seconds with a Cancel button; `/cancel` also works.
- **Cleanup / recovery:** temporary files are removed on success, failure and cancel, and stale folders are swept at
  startup. Failed uploads are retried 3 times; if still failing the file is kept 15 minutes with a "Retry upload" button.
- Files are stored in `DOWNLOAD_DIR` (default `/var/tmp/movie-bot`).
- Known limitation: DNS is checked before connecting but not pinned, so DNS rebinding is not fully excluded.
