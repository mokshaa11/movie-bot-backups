"""Download/upload job management: queueing, progress, cancellation, cleanup, upload retry.

Telegram specifics live in bot.py; this module only needs an `upload` coroutine that
raises UploadRetry (transient) or UploadFatal (permanent).
"""
import asyncio
import logging
import secrets
import shutil
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Awaitable, Callable, Dict, Optional

from downloader import Config, DownloadError, Probe, download

log = logging.getLogger("movie-bot.jobs")

MAX_CONCURRENT = 2
MAX_QUEUED_TOTAL = 8
PENDING_TTL = 600.0
RETAIN_SECONDS = 15 * 60
UPLOAD_ATTEMPTS = 3
PROGRESS_INTERVAL = 4.0


class UploadRetry(Exception):
    def __init__(self, delay: float = 2.0):
        self.delay = delay


class UploadFatal(Exception):
    """Permanent upload failure with a user-safe message."""


@dataclass
class Job:
    id: str
    user_id: int
    chat_id: int
    probe: Probe
    dir: Path
    state: str = "queued"  # queued, downloading, uploading, done, failed, cancelled, upload_failed
    file: Optional[Path] = None
    task: Optional[asyncio.Task] = None
    cleanup_handle: Optional[asyncio.TimerHandle] = None


Notify = Callable[[Job, str], Awaitable[None]]  # (job, text)
Upload = Callable[[Job], Awaitable[None]]


def format_progress(done: int, total: Optional[int], started: float, now: float) -> str:
    speed = done / max(now - started, 0.001)
    mib = done / 1048576
    if total:
        eta = (total - done) / speed if speed > 0 else 0
        return f"Downloading: {done * 100 // total}% ({mib:.1f}/{total / 1048576:.1f} MiB), {speed / 1048576:.1f} MiB/s, ETA {int(eta)}s"
    return f"Downloading: {mib:.1f} MiB so far, {speed / 1048576:.1f} MiB/s"


class JobManager:
    def __init__(self, cfg: Config, clock: Callable[[], float] = time.monotonic):
        self.cfg = cfg
        self._clock = clock
        self.jobs: Dict[str, Job] = {}
        self.pending: Dict[str, tuple] = {}  # id -> (user_id, chat_id, probe, expires)
        self._sem = asyncio.Semaphore(MAX_CONCURRENT)

    # ---- confirmation step -------------------------------------------------
    def add_pending(self, user_id: int, chat_id: int, probe: Probe) -> str:
        now = self._clock()
        for k in [k for k, v in self.pending.items() if v[3] <= now]:
            del self.pending[k]
        pid = secrets.token_urlsafe(6)
        self.pending[pid] = (user_id, chat_id, probe, now + PENDING_TTL)
        return pid

    def take_pending(self, pid: str, user_id: int, chat_id: int) -> Optional[Probe]:
        item = self.pending.get(pid)
        if not item or item[3] <= self._clock() or item[0] != user_id or item[1] != chat_id:
            return None
        del self.pending[pid]
        return item[2]

    # ---- jobs --------------------------------------------------------------
    def user_active(self, user_id: int) -> bool:
        return any(j.user_id == user_id and j.state in ("queued", "downloading", "uploading")
                   for j in self.jobs.values())

    def queued_total(self) -> int:
        return sum(1 for j in self.jobs.values() if j.state in ("queued", "downloading", "uploading"))

    def can_accept(self, user_id: int) -> Optional[str]:
        if self.user_active(user_id):
            return "You already have a transfer in progress. Wait for it to finish or use /cancel."
        if self.queued_total() >= MAX_QUEUED_TOTAL:
            return "The queue is full. Please try again later."
        return None

    def create(self, user_id: int, chat_id: int, probe: Probe) -> Job:
        jid = secrets.token_urlsafe(6)
        job = Job(jid, user_id, chat_id, probe, self.cfg.work_dir / jid)
        self.jobs[jid] = job
        return job

    def get(self, jid: str, user_id: int) -> Optional[Job]:
        j = self.jobs.get(jid)
        return j if j and j.user_id == user_id else None

    def active_for_user(self, user_id: int) -> Optional[Job]:
        return next((j for j in self.jobs.values()
                     if j.user_id == user_id and j.state in ("queued", "downloading", "uploading")), None)

    def cancel(self, job: Job) -> bool:
        if job.task and not job.task.done() and job.state in ("queued", "downloading", "uploading"):
            job.task.cancel()
            return True
        return False

    def cleanup(self, job: Job) -> None:
        if job.cleanup_handle:
            job.cleanup_handle.cancel()
            job.cleanup_handle = None
        shutil.rmtree(job.dir, ignore_errors=True)
        job.file = None

    def forget_later(self, job: Job) -> None:
        """Drop a finished job record (and its files) after the retention window."""
        loop = asyncio.get_running_loop()
        job.cleanup_handle = loop.call_later(RETAIN_SECONDS, self._expire, job)

    def _expire(self, job: Job) -> None:
        self.cleanup(job)
        self.jobs.pop(job.id, None)

    # ---- run ---------------------------------------------------------------
    async def run(self, job: Job, notify: Notify, upload: Upload, client=None) -> None:
        """Download then upload. Always cleans up unless an upload is retained for retry."""
        retain = False
        try:
            async with self._sem:
                job.state = "downloading"
                started = self._clock()
                last = [0.0]

                async def progress(done: int, total: Optional[int]) -> None:
                    now = self._clock()
                    if now - last[0] >= PROGRESS_INTERVAL:
                        last[0] = now
                        await notify(job, format_progress(done, total, started, now))

                await notify(job, "Starting download...")
                job.file = await download(job.probe, job.dir, self.cfg, progress, client)
                retain = await self._upload(job, notify, upload)
        except asyncio.CancelledError:
            job.state = "cancelled"
            await self._safe_notify(notify, job, "Transfer cancelled. Temporary files were removed.")
        except DownloadError as exc:
            job.state = "failed"
            await self._safe_notify(notify, job, f"Download failed: {exc}")
        except Exception:
            log.exception("Unexpected job error")
            job.state = "failed"
            await self._safe_notify(notify, job, "Something went wrong. Temporary files were removed.")
        finally:
            if retain:
                self.forget_later(job)
            else:
                self.cleanup(job)
                self.jobs.pop(job.id, None)

    async def _upload(self, job: Job, notify: Notify, upload: Upload) -> bool:
        """Upload with retries. Returns True if the file is retained for a manual retry."""
        job.state = "uploading"
        await notify(job, "Download complete. Uploading to Telegram...")
        for attempt in range(1, UPLOAD_ATTEMPTS + 1):
            try:
                await upload(job)
                job.state = "done"
                await notify(job, "Done ✅")
                return False
            except UploadRetry as r:
                if attempt == UPLOAD_ATTEMPTS:
                    break
                await notify(job, f"Upload hit a temporary problem, retrying ({attempt}/{UPLOAD_ATTEMPTS - 1})...")
                await asyncio.sleep(min(max(r.delay, 0), 60))
            except UploadFatal as exc:
                job.state = "failed"
                await notify(job, f"Upload failed: {exc}")
                return False
        job.state = "upload_failed"
        await notify(job, "Upload failed after several attempts. The file is kept for 15 minutes so you can retry.")
        return True

    async def retry_upload(self, job: Job, notify: Notify, upload: Upload) -> None:
        """Retry only the upload for a retained file."""
        if job.state != "upload_failed" or not job.file or not job.file.exists():
            await notify(job, "Nothing to retry. Please send the link again.")
            return
        if job.cleanup_handle:
            job.cleanup_handle.cancel()
        retain = False
        try:
            retain = await self._upload(job, notify, upload)
        except asyncio.CancelledError:
            job.state = "cancelled"
            await self._safe_notify(notify, job, "Transfer cancelled. Temporary files were removed.")
        finally:
            if retain:
                self.forget_later(job)
            else:
                self.cleanup(job)
                self.jobs.pop(job.id, None)

    @staticmethod
    async def _safe_notify(notify: Notify, job: Job, text: str) -> None:
        try:
            await notify(job, text)
        except Exception:
            log.warning("Could not send status update")
