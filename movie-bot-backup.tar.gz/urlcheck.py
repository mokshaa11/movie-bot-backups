"""Safe validation of TopCinema URLs."""
import re
from typing import Optional
from urllib.parse import urlsplit

ALLOWED_DOMAIN = "web.topcinema.io"
URL_RE = re.compile(r"https?://\S+", re.IGNORECASE)


def validate_topcinema_url(text: str) -> Optional[str]:
    """Return a normalized URL if it points to web.topcinema.io (or a subdomain), else None."""
    if not text or len(text) > 2048:
        return None
    candidate = text.strip()
    if any(c.isspace() or ord(c) < 32 for c in candidate):
        return None
    try:
        parts = urlsplit(candidate)
        host = parts.hostname  # lowercased, userinfo/port stripped
        _ = parts.port  # raises ValueError on invalid port
    except ValueError:
        return None
    if parts.scheme not in ("http", "https") or not host:
        return None
    if parts.username is not None or parts.password is not None:
        return None  # reject user@host tricks
    if parts.port not in (None, 80, 443):
        return None
    host = host.rstrip(".")
    # Exact match or a true subdomain (dot boundary prevents "evilweb.topcinema.io").
    if host != ALLOWED_DOMAIN and not host.endswith("." + ALLOWED_DOMAIN):
        return None
    if not re.fullmatch(r"[a-z0-9.-]+", host) or ".." in host:
        return None
    return candidate


def find_url(text: str) -> Optional[str]:
    """Extract the first http(s) URL from a message."""
    m = URL_RE.search(text or "")
    return m.group(0) if m else None
