import asyncio
import httpx
import pytest
from bot import format_result
from extractor import ExtractionError, fetch_page, parse_page

BASE = "https://web.topcinema.io/film/x/"

HTML = """<html><head><title> Movie &amp; Co </title></head><body>
<video controls><source src="/v/a-720p.mp4" label="720p" type="video/mp4">
<source src="https://cdn.example.com/b.mp4" title="1080p"></video>
<script>var u="https:\\/\\/cdn.example.com\\/stream\\/master.m3u8?x=1";</script>
<iframe src="https://player.example.org/embed/1"></iframe></body></html>"""


def test_parse_sources_and_quality():
    r = parse_page(HTML, BASE)
    assert r.title == "Movie & Co"
    urls = {s.url: s for s in r.sources}
    assert urls["https://web.topcinema.io/v/a-720p.mp4"].quality == "720p"
    assert urls["https://cdn.example.com/b.mp4"].quality == "1080p"
    assert urls["https://cdn.example.com/stream/master.m3u8?x=1"].kind == "hls"
    assert [s.quality for s in r.sources][:2] == ["1080p", "720p"]
    assert r.embeds == ["https://player.example.org/embed/1"]


def test_drm_pages_yield_no_sources():
    r = parse_page(HTML + "<script>navigator.requestMediaKeySystemAccess('com.widevine.alpha')</script>", BASE)
    assert r.drm_detected and r.sources == []
    assert "DRM" in format_result(r)


def test_no_sources_message():
    assert "No directly accessible" in format_result(parse_page("<html></html>", BASE))


def _client(handler):
    return httpx.AsyncClient(transport=httpx.MockTransport(handler), follow_redirects=False)


def run(c):
    return asyncio.run(c)


def test_fetch_ok():
    h = lambda req: httpx.Response(200, text="<html>ok</html>", headers={"content-type": "text/html"})
    assert "ok" in run(fetch_page(BASE, _client(h)))


def test_redirect_off_domain_rejected():
    h = lambda req: httpx.Response(302, headers={"location": "https://evil.com/"})
    with pytest.raises(ExtractionError):
        run(fetch_page(BASE, _client(h)))


def test_redirect_within_domain_ok():
    def h(req):
        if req.url.path == "/film/x/":
            return httpx.Response(302, headers={"location": "/other"})
        return httpx.Response(200, text="hi", headers={"content-type": "text/html"})
    assert run(fetch_page(BASE, _client(h))) == "hi"


@pytest.mark.parametrize("status", [403, 404])
def test_http_errors(status):
    with pytest.raises(ExtractionError):
        run(fetch_page(BASE, _client(lambda r: httpx.Response(status))))


def test_too_large_and_non_html():
    big = lambda r: httpx.Response(200, content=b"a" * (3 * 1024 * 1024), headers={"content-type": "text/html"})
    with pytest.raises(ExtractionError):
        run(fetch_page(BASE, _client(big)))
    js = lambda r: httpx.Response(200, text="{}", headers={"content-type": "application/json"})
    with pytest.raises(ExtractionError):
        run(fetch_page(BASE, _client(js)))


DL_HTML = """<div class="DownloadBox"><div class="proServer">
<a target="_NEW" rel="nofollow" href="https://down.vidtube.one/d/abc.html" class="downloadsLink proServer green">
<div class="text"><span>VideoTube</span><p>1080p - 720p - 480p</p></div></a></div>
<div class="DownloadBlock"><h2 class="download-title"><i class="fal fa-download"></i>تحميل <span>1080p</span></h2>
<ul><li><a target="_NEW" href="https://updown.cam/xyz" class="downloadsLink green">
<div class="text"><span>UpDown</span><p>1080p</p></div></a></li>
<li><a href="https://user:pw@evil.example/x" class="downloadsLink"><div class="text"><span>Bad</span><p>1080p</p></div></a></li>
</ul></div></div>"""


def test_parse_download_page():
    from extractor import parse_download_page
    links = parse_download_page(DL_HTML)
    assert [(l.host, l.quality, l.url) for l in links] == [
        ("VideoTube", "1080p - 720p - 480p", "https://down.vidtube.one/d/abc.html"),
        ("UpDown", "1080p", "https://updown.cam/xyz")]


def test_server_list_and_embed_snippet():
    from extractor import parse_server_list, parse_embed_snippet
    html = '<li data-id="5" data-server="0" class="a"></li><li data-id="5" data-server="1" class="a"></li>'
    assert parse_server_list(html) == [("5", "0"), ("5", "1")]
    assert parse_embed_snippet('<iframe src="https://p.example/embed-1.html" x>') == "https://p.example/embed-1.html"
    assert parse_embed_snippet("nothing") is None


def test_base_page_url():
    from extractor import base_page_url
    assert base_page_url("https://web.topcinema.io/a/watch/?x=1") == "https://web.topcinema.io/a/"
    assert base_page_url("https://web.topcinema.io/a/download") == "https://web.topcinema.io/a/"
    assert base_page_url("https://web.topcinema.io/a") == "https://web.topcinema.io/a/"


def test_extract_sources_only_contacts_allowed_domain():
    from extractor import extract_sources
    hosts = []
    watch = '<li data-id="5" data-server="1" class="x"></li>'

    def h(req):
        hosts.append(req.url.host)
        p = req.url.path
        if req.method == "POST":
            return httpx.Response(200, text='<iframe src="https://okstream.example/e.html">', headers={"content-type": "text/html"})
        body = DL_HTML if p.endswith("/download/") else watch if p.endswith("/watch/") else "<title>t</title>"
        return httpx.Response(200, text=body, headers={"content-type": "text/html"})

    r = run(extract_sources(BASE, _client(h)))
    assert {l.host for l in r.downloads} == {"VideoTube", "UpDown"}
    assert r.embeds == ["https://okstream.example/e.html"]
    assert set(hosts) == {"web.topcinema.io"}  # third-party URLs were never requested


def test_format_omits_embeds_and_links():
    from extractor import ExtractionResult, DownloadLink
    out = format_result(ExtractionResult(embeds=["https://p.example/e"],
                                         downloads=[DownloadLink("UpDown", "1080p", "https://updown.cam/x")]))
    assert "p.example" not in out and "updown" not in out and "do not download" in out
