import asyncio

import httpx
import pytest

import jobs
from downloader import MIB, Config, Probe
from jobs import JobManager, UploadFatal, UploadRetry, format_progress

URL = "https://files.example.com/movie.mp4"


def run(c):
    return asyncio.run(c)


def cfg(tmp_path):
    return Config(work_dir=tmp_path / "work", disk_reserve_bytes=0)


def client(body=b"x" * 1000, slow=False):
    async def gen():
        for _ in range(100):
            yield b"x" * 1000
            await asyncio.sleep(0.05)

    def h(r):
        return httpx.Response(200, headers={"content-type": "video/mp4"}, content=gen() if slow else body)
    return httpx.AsyncClient(transport=httpx.MockTransport(h), follow_redirects=False)


class Rec:
    def __init__(self):
        self.msgs = []

    async def notify(self, job, text):
        self.msgs.append((job.state, text))


def make(tmp_path, size=1000):
    m = JobManager(cfg(tmp_path))
    job = m.create(1, 10, Probe(URL, size, "video/mp4", "f.mp4"))
    return m, job


def test_success_cleans_up(tmp_path):
    m, job = make(tmp_path)
    rec, seen = Rec(), []

    async def upload(j):
        seen.append(j.file.read_bytes())
    run(m.run(job, rec.notify, upload, client()))
    assert seen == [b"x" * 1000] and rec.msgs[-1][1].startswith("Done")
    assert not job.dir.exists() and job.id not in m.jobs


def test_transient_upload_failure_then_success(tmp_path):
    m, job = make(tmp_path)
    rec, n = Rec(), [0]

    async def upload(j):
        n[0] += 1
        if n[0] < 3:
            raise UploadRetry(0)
    run(m.run(job, rec.notify, upload, client()))
    assert n[0] == 3 and rec.msgs[-1][1].startswith("Done") and not job.dir.exists()


def test_upload_failure_retains_file_then_manual_retry(tmp_path):
    async def go():
        m, job = make(tmp_path)
        rec, ok = Rec(), [False]

        async def upload(j):
            if not ok[0]:
                raise UploadRetry(0)
        await m.run(job, rec.notify, upload, client())
        assert job.state == "upload_failed" and job.file.exists() and job.id in m.jobs
        assert "kept for 15 minutes" in rec.msgs[-1][1]
        ok[0] = True
        await m.retry_upload(job, rec.notify, upload)
        assert rec.msgs[-1][1].startswith("Done") and not job.dir.exists() and job.id not in m.jobs
    run(go())


def test_retained_file_expires(tmp_path, monkeypatch):
    async def go():
        monkeypatch.setattr(jobs, "RETAIN_SECONDS", 0.05)
        m, job = make(tmp_path)

        async def upload(j):
            raise UploadRetry(0)
        await m.run(job, Rec().notify, upload, client())
        assert job.dir.exists()
        await asyncio.sleep(0.2)
        assert not job.dir.exists() and job.id not in m.jobs
    run(go())


def test_fatal_upload_not_retried(tmp_path):
    m, job = make(tmp_path)
    rec, n = Rec(), [0]

    async def upload(j):
        n[0] += 1
        raise UploadFatal("Telegram rejected the file.")
    run(m.run(job, rec.notify, upload, client()))
    assert n[0] == 1 and "rejected" in rec.msgs[-1][1] and not job.dir.exists()


def test_cancel_during_download(tmp_path):
    async def go():
        m, job = make(tmp_path, size=None)
        rec = Rec()

        async def upload(j):
            raise AssertionError("must not upload")
        job.task = asyncio.create_task(m.run(job, rec.notify, upload, client(slow=True)))
        await asyncio.sleep(0.3)
        assert m.cancel(job)
        await job.task
        assert job.state == "cancelled" and not job.dir.exists()
        assert "cancelled" in rec.msgs[-1][1] and job.id not in m.jobs
    run(go())


def test_download_error_reported(tmp_path):
    m, job = make(tmp_path)
    rec = Rec()
    bad = httpx.AsyncClient(transport=httpx.MockTransport(lambda r: httpx.Response(403)))
    run(m.run(job, rec.notify, None, bad))
    assert "Download failed" in rec.msgs[-1][1] and not job.dir.exists()


def test_limits_and_pending(tmp_path):
    now = [0.0]
    m = JobManager(cfg(tmp_path), clock=lambda: now[0])
    pr = Probe(URL, 1, "video/mp4", "f.mp4")
    assert m.can_accept(1) is None
    m.create(1, 10, pr)
    assert "already have" in m.can_accept(1)
    assert m.can_accept(2) is None
    for u in range(100, 100 + jobs.MAX_QUEUED_TOTAL):
        m.create(u, 10, pr)
    assert "queue is full" in m.can_accept(999)
    pid = m.add_pending(1, 10, pr)
    assert m.take_pending(pid, 2, 10) is None and m.take_pending(pid, 1, 11) is None
    assert m.take_pending(pid, 1, 10) is pr and m.take_pending(pid, 1, 10) is None
    pid = m.add_pending(1, 10, pr)
    now[0] = jobs.PENDING_TTL + 1
    assert m.take_pending(pid, 1, 10) is None


def test_format_progress():
    assert "50%" in format_progress(5 * MIB, 10 * MIB, 0.0, 5.0)
    assert "so far" in format_progress(5 * MIB, None, 0.0, 5.0)
