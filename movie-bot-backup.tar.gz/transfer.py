"""Telegram handlers for /download, confirmation, progress, cancel and upload retry."""
import asyncio
import logging
import os
from typing import Optional

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.error import BadRequest, Forbidden, NetworkError, RetryAfter, TelegramError
from telegram.ext import ContextTypes

from downloader import MIB, Config, DownloadError, check_size_allowed, parse_allowed_users, probe
from jobs import Job, JobManager, UploadFatal, UploadRetry
from linkcheck import validate_external_url

log = logging.getLogger("movie-bot.transfer")

CFG = Config.from_env()
MANAGER = JobManager(CFG)
ALLOWED = parse_allowed_users(os.environ.get("ALLOWED_USER_IDS", ""))
_tasks: set = set()  # keep strong references to running tasks

CONFIRM_TEXT = "✅ I confirm I have the right to download this file"
USAGE = ("Usage: /download <direct file URL>\n"
         "Only direct video file links (mp4, mkv, webm, mov, m4v, avi) are accepted, not web pages. "
         f"Files above {CFG.upload_limit_bytes // 1_000_000} MB can't be uploaded and are rejected.")


def _kb(*buttons) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[InlineKeyboardButton(t, callback_data=d)] for t, d in buttons])


def make_notify(message):
    """Return a notify() that edits one status message, tolerating Telegram edit errors."""
    last = {"text": None}

    async def notify(job: Job, text: str) -> None:
        if text == last["text"]:
            return
        last["text"] = text
        markup = None
        if job.state in ("queued", "downloading", "uploading"):
            markup = _kb(("Cancel", f"dl:cancel:{job.id}"))
        elif job.state == "upload_failed":
            markup = _kb(("Retry upload", f"dl:retry:{job.id}"))
        try:
            await message.edit_text(text, reply_markup=markup)
        except RetryAfter:
            pass  # skip this progress update; the next one will go through
        except BadRequest:
            pass  # e.g. message not modified
        except TelegramError as exc:
            log.warning("Status update failed: %s", type(exc).__name__)

    return notify


def make_uploader(bot):
    async def upload(job: Job) -> None:
        try:
            with open(job.file, "rb") as fh:
                await bot.send_document(job.chat_id, document=fh, filename=job.probe.filename,
                                        read_timeout=600, write_timeout=600, connect_timeout=30)
        except RetryAfter as exc:
            delay = exc.retry_after.total_seconds() if hasattr(exc.retry_after, "total_seconds") else exc.retry_after
            raise UploadRetry(float(delay))
        except (BadRequest, Forbidden) as exc:  # permanent: do not retry
            if isinstance(exc, Forbidden):
                raise UploadFatal("I'm not allowed to send messages to this chat.")
            raise UploadFatal("Telegram rejected the file.")
        except NetworkError:  # includes timeouts
            raise UploadRetry(3.0)
        except TelegramError:
            raise UploadFatal("Telegram returned an error.")
        except OSError:
            raise UploadFatal("The downloaded file could not be read.")

    return upload


def _authorized(user_id: int) -> Optional[str]:
    if not ALLOWED:
        return "Downloads are disabled: no allowed users are configured (ALLOWED_USER_IDS)."
    if user_id not in ALLOWED:
        log.warning("Unauthorized download attempt from user %s", user_id)
        return "You are not authorized to use downloads."
    return None


def _fallback_kb(url: Optional[str]) -> Optional[InlineKeyboardMarkup]:
    return InlineKeyboardMarkup([[InlineKeyboardButton("🔗 Open the link yourself", url=url)]]) if url else None


async def offer_download(reply, user_id: int, chat_id: int, url: str, fallback_url: Optional[str] = None,
                         premium: bool = False) -> None:
    """Probe a user-chosen URL and, if it is a downloadable direct file, ask for confirmation.

    `reply(text, reply_markup=None)` sends a message. Landing pages, restricted links and
    oversize files are explained, and the original link is kept as a fallback button.
    """
    if err := _authorized(user_id):
        await reply(err)
        return
    if err := MANAGER.can_accept(user_id):
        await reply(err)
        return
    if premium:
        await reply("This is a premium host that needs a paid account, so I can't fetch it. "
                    "You can open the link yourself.", reply_markup=_fallback_kb(fallback_url))
        return
    await reply("Checking the link...")
    try:
        pr = await probe(url)
        check_size_allowed(pr.size, CFG)
    except DownloadError as exc:
        await reply(f"I can't download this link: {exc}\n"
                    "Many hosts only offer a web page; the link is kept below as a fallback.",
                    reply_markup=_fallback_kb(fallback_url))
        return
    size = f"{pr.size / MIB:.1f} MiB" if pr.size is not None else "unknown size (I'll stop if it exceeds the limit)"
    pid = MANAGER.add_pending(user_id, chat_id, pr)
    await reply(f"Direct file found: {pr.content_type or 'video'}, {size}.\n"
                "Downloads are for content you are authorized to download.",
                reply_markup=_kb((CONFIRM_TEXT, f"dl:ok:{pid}")))


async def download_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    msg, user = update.message, update.effective_user
    if err := _authorized(user.id):
        await msg.reply_text(err)
        return
    args = getattr(context, "args", None) or []
    url = validate_external_url(args[0]) if args else None
    if not url:
        await msg.reply_text(USAGE)
        return
    await offer_download(msg.reply_text, user.id, update.effective_chat.id, url)


async def on_transfer_button(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    q = update.callback_query
    await q.answer()
    parts = (q.data or "").split(":")
    if len(parts) != 3 or parts[0] != "dl":
        return
    action, ident = parts[1], parts[2]
    user, chat = update.effective_user, update.effective_chat
    if err := _authorized(user.id):
        await q.edit_message_text(err)
        return
    notify = make_notify(q.message)
    if action == "ok":
        pr = MANAGER.take_pending(ident, user.id, chat.id)
        if not pr:
            await q.edit_message_text("This confirmation expired. Please run /download again.")
            return
        if err := MANAGER.can_accept(user.id):
            await q.edit_message_text(err)
            return
        job = MANAGER.create(user.id, chat.id, pr)
        task = asyncio.create_task(MANAGER.run(job, notify, make_uploader(context.bot)))
        job.task = task
        _tasks.add(task)
        task.add_done_callback(_tasks.discard)
    elif action == "cancel":
        job = MANAGER.get(ident, user.id)
        if not job or not MANAGER.cancel(job):
            await q.edit_message_text("Nothing to cancel.")
    elif action == "retry":
        job = MANAGER.get(ident, user.id)
        if not job or job.state != "upload_failed":
            await q.edit_message_text("Nothing to retry. Please run /download again.")
            return
        task = asyncio.create_task(MANAGER.retry_upload(job, notify, make_uploader(context.bot)))
        job.task = task
        _tasks.add(task)
        task.add_done_callback(_tasks.discard)


async def cancel_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if err := _authorized(update.effective_user.id):
        await update.message.reply_text(err)
        return
    job = MANAGER.active_for_user(update.effective_user.id)
    if job and MANAGER.cancel(job):
        await update.message.reply_text("Cancelling your transfer...")
    else:
        await update.message.reply_text("You have no active transfer.")
