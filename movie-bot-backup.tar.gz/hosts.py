"""Host-specific resolvers for file hosts that publicly offer a free direct link.

Only VideoTube (down.vidtube.one) is supported: its free quality-selection page lists
direct download links with no login, payment, CAPTCHA, countdown token or DRM involved.
Other hosts (UpDown, BowFile, KoramaUp, 1CloudFile, Mdiaload, ...) use timer/token/JS or
Cloudflare-gated flows and are intentionally NOT supported. Every request goes through
the same URL validation, redirect re-validation and public-IP checks as downloads.
"""
import logging
import re
from dataclasses import dataclass
from html import unescape
from typing import List, Optional
from urllib.parse import urljoin, urlsplit

import httpx

from downloader import MAX_REDIRECTS, DownloadError, _open, new_client
from linkcheck import validate_external_url

log = logging.getLogger("movie-bot.hosts")

MAX_PAGE_BYTES = 1024 * 1024
VIDTUBE_SUFFIX = "vidtube.one"
_VT_PATH_RE = re.compile(r"^/d/([a-z0-9]{6,32})(?:\.html)?$", re.I)
_VT_OPTION_PATH_RE = re.compile(r"^/d/[a-z0-9]{6,32}_[a-z0-9]$", re.I)
_A_RE = re.compile(r"<a\b[^>]*\bhref=[\"']([^\"']+)[\"'][^>]*>(.*?)</a>", re.I | re.S)
_QUALITY_RE = re.compile(r"(?<!\d)(\d{3,4})p\b", re.I)
_SIZE_RE = re.compile(r"([\d.,]+)\s*(KB|MB|GB)\b", re.I)
_MEDIA_HREF_RE = re.compile(r"<a\b[^>]*\bhref=[\"'](https?://[^\"']+?\.(?:mp4|mkv|webm|mov|m4v)(?:\?[^\"']*)?)[\"']", re.I)
_UNIT = {"KB": 1000, "MB": 1000 * 1000, "GB": 1000 * 1000 * 1000}


@dataclass
class Option:
    quality: str  # e.g. "240p"
    size: Optional[int]  # bytes (approximate, as shown by the host)
    url: str  # host page that holds the direct link


def host_name(url: str) -> str:
    return (urlsplit(url).hostname or "").lower()


def is_vidtube_url(url: str) -> bool:
    p = urlsplit(url)
    h = (p.hostname or "").lower()
    return (h == VIDTUBE_SUFFIX or h.endswith("." + VIDTUBE_SUFFIX)) and p.scheme in ("http", "https") \
        and bool(_VT_PATH_RE.match(p.path))


def supported_host(url: str) -> Optional[str]:
    return "VideoTube" if is_vidtube_url(url) else None


def _same_family(url: str) -> bool:
    h = host_name(url)
    return h == VIDTUBE_SUFFIX or h.endswith("." + VIDTUBE_SUFFIX)


async def _fetch_html(url: str, client: Optional[httpx.AsyncClient], check_dns: bool) -> str:
    """GET an HTML page on the VideoTube family only, with size limit and revalidated redirects."""
    try:
        resp, final = await _open(client, url, "GET", None, check_dns)
        try:
            if not _same_family(final):
                raise DownloadError("The host redirected somewhere unexpected.")
            if resp.status_code in (401, 402, 403, 407):
                raise DownloadError("The host requires access I don't have (login or restricted).")
            if resp.status_code != 200:
                raise DownloadError(f"The host returned HTTP {resp.status_code}.")
            if "html" not in resp.headers.get("content-type", "").lower():
                raise DownloadError("The host returned an unexpected response.")
            data = bytearray()
            async for chunk in resp.aiter_bytes():
                data += chunk
                if len(data) > MAX_PAGE_BYTES:
                    raise DownloadError("The host page is too large.")
            return data.decode(resp.encoding or "utf-8", errors="replace")
        finally:
            await resp.aclose()
    except httpx.TimeoutException:
        raise DownloadError("The host took too long to respond.")
    except httpx.HTTPError:
        raise DownloadError("Could not reach the host.")


def _parse_size(text: str) -> Optional[int]:
    m = _SIZE_RE.search(text)
    if not m:
        return None
    try:
        return int(float(m.group(1).replace(",", ".")) * _UNIT[m.group(2).upper()])
    except ValueError:
        return None


def parse_vidtube_options(html: str, page_url: str) -> List[Option]:
    """Read the quality list: links like /d/<id>_<code> with a '720p' label and a size."""
    options, seen = [], set()
    for href, inner in _A_RE.findall(html):
        url = urljoin(page_url, unescape(href))
        if not _same_family(url) or not _VT_OPTION_PATH_RE.match(urlsplit(url).path) or url in seen:
            continue
        text = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", unescape(inner)))
        q = _QUALITY_RE.search(text)
        if not q or not validate_external_url(url):
            continue
        seen.add(url)
        options.append(Option(q.group(1) + "p", _parse_size(text), url))
    options.sort(key=lambda o: -int(o.quality[:-1]))
    return options


def parse_vidtube_direct(html: str) -> Optional[str]:
    """Return the direct media link shown on a free 'Direct Download Link' page, if any."""
    m = _MEDIA_HREF_RE.search(html)
    return validate_external_url(unescape(m.group(1))) if m else None


async def vidtube_options(url: str, client: Optional[httpx.AsyncClient] = None) -> List[Option]:
    own = client is None
    client = client or new_client()
    try:
        opts = parse_vidtube_options(await _fetch_html(url, client, own), url)
        if not opts:
            raise DownloadError("No free download options were found on the VideoTube page.")
        return opts
    finally:
        if own:
            await client.aclose()


async def vidtube_direct_url(option_url: str, client: Optional[httpx.AsyncClient] = None) -> str:
    own = client is None
    client = client or new_client()
    try:
        direct = parse_vidtube_direct(await _fetch_html(option_url, client, own))
        if not direct:
            raise DownloadError("VideoTube did not offer a free direct link for this quality "
                                "(it may need a login, payment or a captcha).")
        return direct
    finally:
        if own:
            await client.aclose()
