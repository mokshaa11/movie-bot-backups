"""Telegram bot that accepts TopCinema URLs. Video processing is NOT implemented yet."""
import logging
import os
import re
import sys

from telegram import Update
from telegram.ext import (Application, CallbackQueryHandler, CommandHandler,
                          ContextTypes, MessageHandler, filters)

from extractor import ExtractionError, extract_sources
from menu import (QUALITY_TEXT, MenuStore, group_by_quality, hosts_keyboard,
                  hosts_text, is_premium, quality_keyboard)
from transfer import cancel_command, download_command, offer_download, on_transfer_button
from urlcheck import find_url, validate_topcinema_url

MENUS = MenuStore()
_TOKEN_RE = re.compile(r"\d{6,}:[A-Za-z0-9_-]{20,}")


class RedactFilter(logging.Filter):
    """Redact the bot token and anything shaped like one from log records."""

    def filter(self, record: logging.LogRecord) -> bool:
        msg = record.getMessage()
        token = os.environ.get("BOT_TOKEN", "")
        if token:
            msg = msg.replace(token, "[REDACTED]")
        record.msg, record.args = _TOKEN_RE.sub("[REDACTED]", msg), ()
        return True


def setup_logging() -> logging.Logger:
    handler = logging.StreamHandler()
    handler.addFilter(RedactFilter())
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s"))
    logging.basicConfig(level=logging.INFO, handlers=[handler])
    logging.getLogger("httpx").setLevel(logging.WARNING)  # its URLs contain the token
    return logging.getLogger("movie-bot")


log = setup_logging()

HELP = (
    "Send me a TopCinema link (web.topcinema.io) and I will validate it.\n\n"
    "Commands:\n/start - welcome message\n/help - show this help\n"
    "/download <direct file URL> - download a direct video file and send it here (authorized users only)\n"
    "/cancel - cancel your active transfer\n\n"
    "Notes: downloading from TopCinema pages or third-party landing pages is not supported. "
    "Only direct file links work, and files above 50 MB cannot be uploaded yet."
)


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text("Hello! 🎬 I accept TopCinema links.\n\n" + HELP)


async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text(HELP)


async def handle_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    text = update.message.text or ""
    raw = find_url(text)
    if not raw:
        await update.message.reply_text("Please send a TopCinema URL, e.g. https://web.topcinema.io/...")
        return
    url = validate_topcinema_url(raw)
    if not url:
        await update.message.reply_text("Sorry, that link is not allowed. Only web.topcinema.io URLs are accepted.")
        return
    log.info("Accepted a valid TopCinema URL from chat %s", update.effective_chat.id)
    await update.message.reply_text("Checking the page for public video sources...")
    try:
        result = await extract_sources(url)
    except ExtractionError as exc:
        await update.message.reply_text(f"Could not read the page: {exc}")
        return
    await update.message.reply_text(format_result(result))
    groups = group_by_quality(result.downloads) if not result.drm_detected else []
    if groups:
        token = MENUS.put(update.effective_chat.id, groups)
        await update.message.reply_text(QUALITY_TEXT, reply_markup=quality_keyboard(token, groups))
    else:
        await update.message.reply_text("I found no valid download links on that page.")


async def on_menu_button(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle quality selection and Back buttons."""
    query = update.callback_query
    await query.answer()
    parts = (query.data or "").split(":")
    chat = update.effective_chat
    groups = MENUS.get(parts[1], chat.id) if len(parts) >= 2 and chat else None
    if groups is None or parts[0] not in ("q", "b", "h"):
        await query.edit_message_text("This menu has expired. Please send the link again.")
        return
    token = parts[1]
    if parts[0] == "h":
        try:
            link = groups[int(parts[2])][1][int(parts[3])]
        except (IndexError, ValueError):
            await query.edit_message_text("That option is no longer available. Please send the link again.")
            return
        await offer_download(query.message.reply_text, update.effective_user.id, chat.id, link.url,
                             fallback_url=link.url, premium=is_premium(link.url))
        return
    if parts[0] == "b":
        await query.edit_message_text(QUALITY_TEXT, reply_markup=quality_keyboard(token, groups))
        return
    try:
        quality, links = groups[int(parts[2])]
    except (IndexError, ValueError):
        await query.edit_message_text("That option is no longer available. Please send the link again.")
        return
    await query.edit_message_text(hosts_text(quality), reply_markup=hosts_keyboard(token, int(parts[2]), links))


def format_result(result) -> str:
    """Build the reply text for an extraction result."""
    lines = []
    if result.title:
        lines.append(f"Page: {result.title}")
    if result.drm_detected:
        lines.append("This page uses DRM-protected playback. I can't and won't process it.")
    elif result.sources:
        lines.append("Public video sources found:")
        for i, s in enumerate(result.sources[:10], 1):
            lines.append(f"{i}. [{s.kind.upper()}] {s.quality or 'quality unknown'}\n{s.url}")
    else:
        lines.append("No directly accessible video files were found in the page HTML.")
    lines.append("\nNote: I do not download from TopCinema pages.")
    return "\n".join(lines)[:4000]


async def on_error(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    log.error("Unhandled error: %s", context.error)
    if isinstance(update, Update) and update.effective_message:
        try:
            await update.effective_message.reply_text("Something went wrong. Please try again later.")
        except Exception:
            log.warning("Failed to send error message")


def main() -> int:
    token = os.environ.get("BOT_TOKEN", "").strip()
    if not token:
        log.error("BOT_TOKEN environment variable is not set.")
        return 1
    app = Application.builder().token(token).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_cmd))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text))
    app.add_handler(CommandHandler("download", download_command))
    app.add_handler(CommandHandler("cancel", cancel_command))
    app.add_handler(CallbackQueryHandler(on_transfer_button, pattern=r"^dl:"))
    app.add_handler(CallbackQueryHandler(on_menu_button, pattern=r"^[qbh]:"))
    app.add_error_handler(on_error)
    from downloader import sweep_stale
    from transfer import CFG
    log.info("Removed %d stale job folders", sweep_stale(CFG.work_dir, 3600))
    log.info("Bot starting")
    app.run_polling()
    return 0


if __name__ == "__main__":
    sys.exit(main())
