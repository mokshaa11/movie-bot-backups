import asyncio
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

import pytest

import bot
from extractor import DownloadLink, ExtractionResult
from linkcheck import validate_external_url as v
from menu import (MAX_HOSTS_PER_QUALITY, TTL_SECONDS, MenuStore, group_by_quality,
                  hosts_keyboard, is_premium, parse_qualities, quality_keyboard)


@pytest.mark.parametrize("u", ["https://updown.cam/64g41zp2uq5c", "http://down.mdiaload.com/x", "https://a.b.example.org:443/p?q=1"])
def test_valid_urls(u):
    assert v(u) == u


@pytest.mark.parametrize("u", [
    "javascript:alert(1)", "ftp://x.com/a", "https://user:pw@x.com/", "https://127.0.0.1/", "https://[::1]/",
    "https://10.0.0.5/a", "https://localhost/a", "https://router.local/a", "https://x.com:8080/", "https://x.com:99999/",
    "https://xn--pple-43d.com/", "https://аpple.com/", "https://nodot/", "https://x.com/a b", "https://x.com/\x00",
    "", "https://" + "a" * 3000 + ".com/", "//x.com/a", "https://x.com\\@evil.com/", "https://1.2.3.4.5/"])
def test_invalid_urls(u):
    assert v(u) is None


def test_parse_qualities():
    assert parse_qualities("1080p - 720p - 480p - 240p") == ["1080p", "720p", "480p", "240p"]
    assert parse_qualities("720P") == ["720p"]
    assert parse_qualities("BluRay") == []


def test_premium_label():
    assert is_premium("https://nitroflare.com/view/X") and is_premium("https://www.rapidgator.net/file/1")
    assert not is_premium("https://updown.cam/x") and not is_premium("https://evilnitroflare.com/x")


LINKS = [DownloadLink("VideoTube", "1080p - 720p", "https://down.vidtube.one/d/a.html"),
         DownloadLink("UpDown", "1080p", "https://updown.cam/a"),
         DownloadLink("Weird", "HD", "https://other.example/w"),
         DownloadLink("Bad", "1080p", "https://127.0.0.1/x"),
         DownloadLink("Dup", "1080p", "https://updown.cam/a")]


def test_grouping():
    g = group_by_quality(LINKS)
    assert [q for q, _ in g] == ["1080p", "720p", "Other"]
    assert [l.host for l in g[0][1]] == ["VideoTube", "UpDown"]  # invalid dropped, duplicate removed
    assert [l.host for l in g[1][1]] == ["VideoTube"]


def test_keyboards():
    g = group_by_quality(LINKS + [DownloadLink("Nitroflare", "1080p", "https://nitroflare.com/view/A")])
    kb = quality_keyboard("tok123", g)
    for row in kb.inline_keyboard:
        assert len(row[0].callback_data.encode()) <= 64
    assert kb.inline_keyboard[0][0].text == "1080p (3)"
    hk = hosts_keyboard("tok123", 0, g[0][1])
    assert any("Premium" in r[0].text for r in hk.inline_keyboard[:-1])
    for r in hk.inline_keyboard[:-1]:
        assert r[0].callback_data.startswith("h:tok123:0:") and len(r[0].callback_data.encode()) <= 64
        assert r[1].url.startswith("https://")  # plain link kept as fallback
    assert hk.inline_keyboard[-1][0].callback_data == "b:tok123"
    many = [DownloadLink(f"H{i}", "720p", f"https://h{i}.example.com/x") for i in range(50)]
    assert len(hosts_keyboard("t", 0, many).inline_keyboard) == MAX_HOSTS_PER_QUALITY + 1


def test_store_expiry_and_chat_binding():
    now = [0.0]
    s = MenuStore(clock=lambda: now[0])
    t = s.put(1, [("720p", [])])
    assert s.get(t, 1) == [("720p", [])]
    assert s.get(t, 2) is None  # other chat
    assert s.get("nope", 1) is None
    now[0] = TTL_SECONDS + 1
    assert s.get(t, 1) is None


def _msg_update(chat=7):
    msg = SimpleNamespace(text="https://web.topcinema.io/a/", reply_text=AsyncMock())
    return SimpleNamespace(message=msg, effective_chat=SimpleNamespace(id=chat))


def test_handler_sends_menu_and_makes_no_extra_requests():
    bot.MENUS = MenuStore()
    upd = _msg_update()
    res = ExtractionResult(downloads=LINKS, embeds=["https://player.example/e"])
    with patch.object(bot, "extract_sources", AsyncMock(return_value=res)) as ex:
        asyncio.run(bot.handle_text(upd, None))
    assert ex.await_count == 1
    sent = [c.args[0] for c in upd.message.reply_text.await_args_list]
    assert not any("player.example" in t or "updown" in t for t in sent)
    assert upd.message.reply_text.await_args_list[-1].kwargs["reply_markup"] is not None


def test_handler_no_links():
    bot.MENUS = MenuStore()
    upd = _msg_update()
    with patch.object(bot, "extract_sources", AsyncMock(return_value=ExtractionResult(downloads=[LINKS[3]]))):
        asyncio.run(bot.handle_text(upd, None))
    assert "no valid download links" in upd.message.reply_text.await_args_list[-1].args[0]


def _cb(data, chat=7):
    q = SimpleNamespace(data=data, answer=AsyncMock(), edit_message_text=AsyncMock())
    return q, SimpleNamespace(callback_query=q, effective_chat=SimpleNamespace(id=chat))


def test_callbacks():
    bot.MENUS = MenuStore()
    g = group_by_quality(LINKS)
    tok = bot.MENUS.put(7, g)
    q, u = _cb(f"q:{tok}:0")
    asyncio.run(bot.on_menu_button(u, None))
    assert "1080p" in q.edit_message_text.await_args.args[0]
    assert "direct video files" in q.edit_message_text.await_args.args[0]
    q, u = _cb(f"b:{tok}")
    asyncio.run(bot.on_menu_button(u, None))
    assert "Choose a quality" in q.edit_message_text.await_args.args[0]
    for bad in (f"q:{tok}:99", f"q:{tok}:x", "q:unknown:0", "q", ""):
        q, u = _cb(bad)
        asyncio.run(bot.on_menu_button(u, None))  # must not raise
        assert "expired" in q.edit_message_text.await_args.args[0] or "no longer" in q.edit_message_text.await_args.args[0]
    q, u = _cb(f"q:{tok}:0", chat=8)  # wrong chat
    asyncio.run(bot.on_menu_button(u, None))
    assert "expired" in q.edit_message_text.await_args.args[0]


def _host_press(tok, data, user=1, chat=7):
    from unittest.mock import AsyncMock as AM
    q = SimpleNamespace(data=data, answer=AM(), edit_message_text=AM(),
                        message=SimpleNamespace(reply_text=AM()))
    u = SimpleNamespace(callback_query=q, effective_chat=SimpleNamespace(id=chat),
                        effective_user=SimpleNamespace(id=user))
    return q, u


@pytest.fixture
def tr(monkeypatch, tmp_path):
    import transfer
    from downloader import Config
    from jobs import JobManager
    monkeypatch.setattr(transfer, "CFG", Config(work_dir=tmp_path / "w", disk_reserve_bytes=0))
    monkeypatch.setattr(transfer, "MANAGER", JobManager(transfer.CFG))
    monkeypatch.setattr(transfer, "ALLOWED", frozenset({1}))
    return transfer


def _setup():
    bot.MENUS = MenuStore()
    g = group_by_quality([DownloadLink("Direct", "720p", "https://files.example.com/a.mp4"),
                          DownloadLink("Nitroflare", "720p", "https://nitroflare.com/view/A")])
    return bot.MENUS.put(7, g), g


def test_host_button_direct_file_offers_confirmation(tr):
    from downloader import MIB, Probe
    tok, g = _setup()
    pr = Probe("https://files.example.com/a.mp4", 5 * MIB, "video/mp4", "x.mp4")
    q, u = _host_press(tok, f"h:{tok}:0:0")
    with patch.object(tr, "probe", AsyncMock(return_value=pr)):
        asyncio.run(bot.on_menu_button(u, None))
    last = q.message.reply_text.await_args
    assert "Direct file found" in last.args[0]
    assert last.kwargs["reply_markup"].inline_keyboard[0][0].callback_data.startswith("dl:ok:")


def test_host_button_landing_page_explains_and_keeps_link(tr):
    from downloader import DownloadError
    tok, g = _setup()
    q, u = _host_press(tok, f"h:{tok}:0:0")
    err = DownloadError("That link is a web page, not a direct file link. I only accept direct file URLs.")
    with patch.object(tr, "probe", AsyncMock(side_effect=err)):
        asyncio.run(bot.on_menu_button(u, None))
    last = q.message.reply_text.await_args
    assert "web page" in last.args[0] and "fallback" in last.args[0]
    assert last.kwargs["reply_markup"].inline_keyboard[0][0].url == "https://files.example.com/a.mp4"


def test_host_button_premium_not_probed(tr):
    tok, g = _setup()
    q, u = _host_press(tok, f"h:{tok}:0:1")
    p = AsyncMock()
    with patch.object(tr, "probe", p):
        asyncio.run(bot.on_menu_button(u, None))
    assert p.await_count == 0 and "premium" in q.message.reply_text.await_args.args[0]


def test_host_button_requires_authorization(tr):
    tok, g = _setup()
    q, u = _host_press(tok, f"h:{tok}:0:0", user=2)
    p = AsyncMock()
    with patch.object(tr, "probe", p):
        asyncio.run(bot.on_menu_button(u, None))
    assert p.await_count == 0 and "not authorized" in q.message.reply_text.await_args.args[0]


def test_host_button_bad_indexes_and_wrong_chat(tr):
    tok, g = _setup()
    for data, chat in ((f"h:{tok}:9:9", 7), (f"h:{tok}:x:y", 7), (f"h:{tok}:0", 7), (f"h:{tok}:0:0", 8)):
        q, u = _host_press(tok, data, chat=chat)
        asyncio.run(bot.on_menu_button(u, None))
        assert q.message.reply_text.await_count == 0
        assert "expired" in q.edit_message_text.await_args.args[0] or "no longer" in q.edit_message_text.await_args.args[0]
