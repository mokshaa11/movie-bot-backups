"""Quality-selection menu built from validated download landing-page links.

The bot never opens these links; URL buttons make Telegram open them in the
user's own client.
"""
import re
import secrets
import time
from dataclasses import dataclass
from typing import Callable, Dict, List, Optional, Tuple
from urllib.parse import urlsplit

from telegram import InlineKeyboardButton, InlineKeyboardMarkup

from extractor import DownloadLink
from linkcheck import validate_external_url

PREMIUM_DOMAINS = ("nitroflare.com", "rapidgator.net", "rapidgator.asia", "katfile.com", "uploaded.net")
TTL_SECONDS = 30 * 60
MAX_MENUS = 200
MAX_HOSTS_PER_QUALITY = 20
OTHER = "Other"

_Q_RE = re.compile(r"(?<!\d)(2160|1440|1080|720|576|480|360|240)\s*p?(?!\d)", re.I)

WARNING = ("These are links to third-party sites. I don't open or check them, and I can't vouch "
           "for their safety or availability. I only download direct video files, never web pages.")


def parse_qualities(label: str) -> List[str]:
    """Split a label like '1080p - 720p' into ['1080p', '720p']; empty list if none."""
    found = []
    for m in _Q_RE.finditer(label or ""):
        q = m.group(1) + "p"
        if q not in found:
            found.append(q)
    return found


def is_premium(url: str) -> bool:
    host = (urlsplit(url).hostname or "").lower()
    return any(host == d or host.endswith("." + d) for d in PREMIUM_DOMAINS)


def _clean_label(text: str) -> str:
    text = "".join(c for c in text if c.isprintable())
    return text.strip()[:30] or "Link"


def group_by_quality(links: List[DownloadLink]) -> List[Tuple[str, List[DownloadLink]]]:
    """Validate links and group them by quality, highest first, 'Other' last.

    Multi-quality hosts appear under each quality they list. Invalid URLs are dropped.
    """
    groups: Dict[str, List[DownloadLink]] = {}
    for link in links:
        url = validate_external_url(link.url)
        if not url:
            continue
        clean = DownloadLink(_clean_label(link.host), link.quality, url)
        for q in parse_qualities(link.quality) or [OTHER]:
            bucket = groups.setdefault(q, [])
            if all(b.url != url for b in bucket):
                bucket.append(clean)
    ordered = sorted((q for q in groups if q != OTHER), key=lambda q: -int(q[:-1]))
    if OTHER in groups:
        ordered.append(OTHER)
    return [(q, groups[q]) for q in ordered]


@dataclass
class _Entry:
    chat_id: int
    groups: List[Tuple[str, List[DownloadLink]]]
    expires: float


class MenuStore:
    """Short-lived in-memory storage so callback_data can stay tiny."""

    def __init__(self, clock: Callable[[], float] = time.monotonic):
        self._clock = clock
        self._items: Dict[str, _Entry] = {}

    def _purge(self) -> None:
        now = self._clock()
        for k in [k for k, e in self._items.items() if e.expires <= now]:
            del self._items[k]
        while len(self._items) >= MAX_MENUS:
            del self._items[next(iter(self._items))]  # oldest first

    def put(self, chat_id: int, groups) -> str:
        self._purge()
        token = secrets.token_urlsafe(6)
        self._items[token] = _Entry(chat_id, groups, self._clock() + TTL_SECONDS)
        return token

    def get(self, token: str, chat_id: int) -> Optional[List[Tuple[str, List[DownloadLink]]]]:
        self._purge()
        e = self._items.get(token)
        return e.groups if e and e.chat_id == chat_id else None


def quality_keyboard(token: str, groups) -> InlineKeyboardMarkup:
    rows = [[InlineKeyboardButton(f"{q} ({len(links)})", callback_data=f"q:{token}:{i}")]
            for i, (q, links) in enumerate(groups)]
    return InlineKeyboardMarkup(rows)


def hosts_keyboard(token: str, group_idx: int, links: List[DownloadLink]) -> InlineKeyboardMarkup:
    """One row per host: a button that tries the host link, plus a plain link fallback."""
    rows = []
    for i, l in enumerate(links[:MAX_HOSTS_PER_QUALITY]):
        name = f"💎 {l.host} (Premium)" if is_premium(l.url) else l.host
        rows.append([InlineKeyboardButton(f"⬇ {name}", callback_data=f"h:{token}:{group_idx}:{i}"),
                     InlineKeyboardButton("🔗 Open", url=l.url)])
    rows.append([InlineKeyboardButton("⬅ Back", callback_data=f"b:{token}")])
    return InlineKeyboardMarkup(rows)


QUALITY_TEXT = "Choose a quality:\n\n" + WARNING


def hosts_text(quality: str) -> str:
    return (f"Hosts for {quality}:\n"
            "⬇ tries to fetch the file if the link is a direct video file (authorized users only, "
            "max 50 MB). 🔗 Open just shows the link for you to open yourself.\n"
            "💎 Premium hosts need a paid account, so I don't try them. "
            "Most hosts give a web page instead of a direct file, which I can't download.\n\n" + WARNING)
