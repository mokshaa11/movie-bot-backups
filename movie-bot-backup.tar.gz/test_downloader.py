import asyncio

import httpx
import pytest

from downloader import (MIB, STANDARD_API_UPLOAD_LIMIT, Config, DownloadError, Probe, check_size_allowed,
                        download, parse_allowed_users, probe, sweep_stale)

URL = "https://files.example.com/movie.mp4"


def run(c):
    return asyncio.run(c)


def client(handler):
    return httpx.AsyncClient(transport=httpx.MockTransport(handler), follow_redirects=False)


def resp(status=200, ctype="video/mp4", **kw):
    return httpx.Response(status, headers={"content-type": ctype, **kw.pop("headers", {})}, **kw)


def cfg(tmp_path, **kw):
    return Config(work_dir=tmp_path / "work", disk_reserve_bytes=0, **kw)


def test_allowed_users():
    assert parse_allowed_users("1, 2,x,,-3") == frozenset({1, 2})
    assert parse_allowed_users("") == frozenset()


def test_config_defaults_and_env(monkeypatch):
    monkeypatch.delenv("MAX_DOWNLOAD_MB", raising=False)
    c = Config.from_env()
    assert c.max_download_bytes == 1024 * MIB and c.disk_reserve_bytes == 2 * 1024 * MIB
    assert c.effective_limit == STANDARD_API_UPLOAD_LIMIT  # upload limit is the binding one
    monkeypatch.setenv("MAX_DOWNLOAD_MB", "10")
    assert Config.from_env().max_download_bytes == 10 * MIB
    monkeypatch.setenv("MAX_DOWNLOAD_MB", "abc")
    assert Config.from_env().max_download_bytes == 1024 * MIB


def test_probe_ok_head():
    h = lambda r: resp(headers={"content-length": "1000"})
    p = run(probe(URL, client(h)))
    assert p.size == 1000 and p.filename.endswith(".mp4") and "movie" not in p.filename


def test_probe_falls_back_to_range_get():
    def h(r):
        if r.method == "HEAD":
            return httpx.Response(405)
        return resp(206, headers={"content-range": "bytes 0-0/4242"}, content=b"x")
    assert run(probe(URL, client(h))).size == 4242


@pytest.mark.parametrize("r,msg", [
    (lambda r: resp(ctype="text/html; charset=utf-8", content=b"<html>"), "web page"),
    (lambda r: httpx.Response(403), "requires access"),
    (lambda r: httpx.Response(404), "HTTP 404"),
    (lambda r: resp(ctype="image/png"), "video"),
])
def test_probe_rejections(r, msg):
    with pytest.raises(DownloadError, match=msg):
        run(probe("https://files.example.com/file", client(r)))


def test_probe_redirect_to_private_rejected():
    h = lambda r: httpx.Response(302, headers={"location": "http://127.0.0.1/x.mp4"})
    with pytest.raises(DownloadError):
        run(probe(URL, client(h)))


def test_probe_rejects_bad_url():
    with pytest.raises(DownloadError):
        run(probe("https://user:pw@files.example.com/a.mp4", client(lambda r: resp())))


def test_size_checks(tmp_path):
    c = cfg(tmp_path)
    check_size_allowed(None, c)
    check_size_allowed(10 * MIB, c)
    with pytest.raises(DownloadError, match="50 MB"):
        check_size_allowed(60 * MIB, c)
    with pytest.raises(DownloadError, match="download limit"):
        check_size_allowed(20 * MIB, cfg(tmp_path, max_download_bytes=10 * MIB))
    huge = Config(work_dir=tmp_path / "w", disk_reserve_bytes=10 ** 15)
    with pytest.raises(DownloadError, match="disk"):
        check_size_allowed(1 * MIB, huge)


def test_download_success(tmp_path):
    body = b"a" * (3 * MIB)
    calls = []

    async def prog(d, t):
        calls.append((d, t))
    h = lambda r: resp(content=body)
    pr = Probe(URL, len(body), "video/mp4", "f.mp4")
    out = run(download(pr, tmp_path / "job", cfg(tmp_path), prog, client(h)))
    assert out.read_bytes() == body and calls[-1] == (len(body), len(body))
    assert [p.name for p in (tmp_path / "job").iterdir()] == ["f.mp4"]


def test_download_incomplete_leaves_nothing(tmp_path):
    h = lambda r: httpx.Response(200, headers={"content-type": "video/mp4"}, content=b"abc")
    pr = Probe(URL, 3, "video/mp4", "f.mp4")

    def bad(r):
        resp_ = h(r)
        resp_.headers["content-length"] = "10"  # claims more than delivered
        return resp_
    with pytest.raises(DownloadError):
        run(download(pr, tmp_path / "job", cfg(tmp_path), None, client(bad)))
    assert not list((tmp_path / "job").iterdir())


def test_download_stops_when_unknown_size_exceeds_cap(tmp_path):
    async def gen():
        for _ in range(10):
            yield b"z" * MIB
    h = lambda r: httpx.Response(200, headers={"content-type": "video/mp4"}, content=gen())
    c = cfg(tmp_path, max_download_bytes=3 * MIB)
    with pytest.raises(DownloadError, match="size limit"):
        run(download(Probe(URL, None, "video/mp4", "f.mp4"), tmp_path / "job", c, None, client(h)))
    assert not list((tmp_path / "job").iterdir())


def test_download_refuses_html_body(tmp_path):
    h = lambda r: resp(ctype="text/html", content=b"<html>")
    with pytest.raises(DownloadError):
        run(download(Probe("https://x.example.com/a.mp4", None, "video/mp4", "f.mp4"), tmp_path / "j", cfg(tmp_path), None, client(h)))


def test_sweep_stale(tmp_path):
    import os, time
    old, new = tmp_path / "old", tmp_path / "new"
    old.mkdir(); new.mkdir()
    os.utime(old, (time.time() - 7200,) * 2)
    assert sweep_stale(tmp_path, 3600) == 1 and not old.exists() and new.exists()
